var typed = new Typed(".auto-type",{
    strings: ["Web Designer","Front-End Developer", "Back-End Developer","Web Designer"],
    typeSpeed: 100,
    backSpeed: 40,
    loop: true
});

// const pro_con = document.getElementsByClassName('project-content');
// const pro_des = document.getElementsByClassName('project-description');
// pro_con.addEventListener('mouseover',()=>{
//     pro_des.style='block';
// });
document.querySelector(".project-card").addEventListener("mouseover",()=>{
        document.querySelector(".project-description").style.display="block";
        

});
document.querySelector(".project-card").addEventListener("mouseout",()=>{
        document.querySelector(".project-description").style.display="none";

});